// This file is intentionally empty.
// Supabase has been completely migrated to MongoDB.
// This file is kept as a placeholder to prevent import errors
// until all imports are updated.

export const supabase = null;
